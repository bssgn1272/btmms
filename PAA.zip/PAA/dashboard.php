<!DOCTYPE html>
<html>
<head>
  <title></title>
   <link rel="stylesheet" href="css/dashboard.css">
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity=" sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
</head>
<body>
  <main>
  <div id="container">
  <div id="sideMenu">
   <div id="profilePic">
        <img src="logo/logo.png">
      </div>

    <ul class="menu">
      <li>Dashboard</li>
    
      <li><a href="http://localhost/PAA/departures.php"  target="_blank"><i class='material-icons'  style=" margin-right: 10px;   font-size:20px; text-align: center;" >&#xe91a</i>
        Displays
      </a></li>
      <li><a href="http://localhost/PAA/post.php"><i class='material-icons'  style=" margin-right: 10px;  font-size:20px; text-align: center;" >&#xe254</i>
      Posts
    </a></li>
       <li><a href="http://localhost/PAA/Settings.php"><i class='material-icons' style=" margin-right: 10px;  font-size:20px; text-align: center;" >&#xe8b8</i>
       Settings
     </a></li>

    </ul>


    <div class="addCategory"><span class="plus">+</span> Add Category</div>
  </div>
  <div id="content">
         <section class="digital-marketing-service" id="digital-marketing-section">
        <div class="row align-items-center">
          <div class="col-12 col-lg-7 grid-margin grid-margin-lg-0" data-aos="fade-right">
            <h3 class="m-0">Welcome To Public Announcement System</h3>
          </div>
        </div>
        <div class="row align-items-center">
          <div class="col-12 col-lg-7 text-center flex-item grid-margin" data-aos="fade-right">
            <img src="logo/services.jpg" alt="" class="img-fluid">
          </div>
          <div class="col-12 col-lg-5 flex-item grid-margin" data-aos="fade-left">
            <h3 class="m-0">Dashboard Information</h3>
            <div class="col-lg-9 col-xl-8 p-0">
              <p class="py-4 m-0 text-muted">The Public Announcement System displays a Departures screen with 20 Buses scheduled for the given day..</p>
              <p class="pb-2 font-weight-medium text-muted">The Public Announcement System displays Bus information by Bus License (Number), Time, Company, Bay and Status..</p>
            </div>
            <button class="btn btn-primary btn-sm">Read More</button>
          </div>
        </div>
      </section>     
    </div>
  </div>

</main>
 <script src="dashboard.js"></script>
</body>
</html>