<?php

class Configs{
	const INFO ='../logs/info.log';
	const ERROR = '../logs/error.log';



 const servername = "localhost";
 const username = "root";
 const password = "";
 const dbname = "napsa_ed";
}


?>
