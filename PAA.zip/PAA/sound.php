<?php
$string =" Welcome ! Kindly find your bus and head to the designated waiting area . Enjoy your trip ";
 if($string){
  //get the text 

   $text = substr($string, 0, 100);
//$text = substr($_POST['textbox'], 0, 100);
   //we are passing as a query string so encode it, space will become +
   $text = urlencode($text);
   //give a file name and path to store the file
   $file  = date();
   $file =  $file . ".mp3";
   //now get the content from the Google API using file_get_contents
$url ="https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=".$text;
   //$mp3 = file_get_contents("https://translate.google.com/translate_tts?tl=en&q=$text?client=tw-ob");
$mp3 = file_get_contents($url);
//var_dump($mp3);
   //save the mp3 file to the path
   file_put_contents($file, $mp3);
}s
?>

<?php  if($string){?>
<!-- play the audio file using a player. Here I'm used a HTML5 player. You can use any player insted-->
<audio id="my_audio" controls="controls" src="<?php echo $file; ?>" autoplay="autoplay" loop="loop">
  
</audio>
<?php }?>
<br />
<a href="https://blog.theonlytutorials.com/php-script-text-speech-google-api/">Find the tutorial here - Blog.Theonlytutorials.com</a>
</body><script>
window.onload = function() {
    document.getElementById("my_audio").play();
}
</script>
</html>
