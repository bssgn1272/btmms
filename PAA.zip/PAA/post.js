$(".label").mousedown(function(e){
  $(this).addClass("active");
}).mouseclick(funtion(e){
  $(this).removeClass("active")
  }).mouseout(function(){
    $(this).removeClass("active");
  });
          