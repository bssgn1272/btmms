<?php
require 'Configs.php';
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */

          $link = new mysqli(Configs::servername,Configs::username,Configs::password,Configs::dbname);
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Escape user inputs for security
$size = mysqli_real_escape_string($link, $_REQUEST['size']);
if($size){
if(mysqli_query($link,"UPDATE ed_post_setting set size ='$size'")){

    echo '<script>
            $(function() {
                $( "#dialog" ).dialog({
                    autoOpen: true,
                    modal: true,
                    width: 300,
                    height: 200,
                  });
            });
             </script>'
              .'<div id="dialog" title="Basic dialog">
                     <p>Records UPDATED successfully</p>
               </div>';
} else{
    echo "ERROR: Could not be able to execute $sql. " . mysqli_error($link);
}}
$color = mysqli_real_escape_string($link, $_REQUEST['color']);
if($color){
if(mysqli_query($link,"UPDATE ed_post_setting set color='$color'")){

    echo '<script>
            $(function() {
                $( "#dialog" ).dialog({
                    autoOpen: true,
                    modal: true,
                    width: 300,
                    height: 200,
                  });
            });
             </script>'
              .'<div id="dialog" title="Basic dialog">
                     <p>Records UPDATED successfully</p>
               </div>';
} else{
    echo "ERROR: Could not be able to execute $sql. " . mysqli_error($link);
}
}
//Close connection
mysqli_close($link);

?>
