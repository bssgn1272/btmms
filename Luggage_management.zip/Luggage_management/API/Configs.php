<?php

class Configs{
	const INFO ='/var/www/html/Luggage_management/Access_control/logs/info.log';
	const ERROR = '/var/www/html/Luggage_management/Access_control/logs/error.log';
        const FORMAT = 'jpeg';
        const IMAGEPATH = '/home/daemon30000/Documents/Access_control/images/';

}

?>
