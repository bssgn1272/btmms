<?php

class Configs{
	const INFO ='../logs/info.log';
	const ERROR = '../logs/error.log';


}

?>
