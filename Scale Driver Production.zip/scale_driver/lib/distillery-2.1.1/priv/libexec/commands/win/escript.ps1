## This command is used to execute an escript using the release ERTS

escript @args
