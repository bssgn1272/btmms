## Evaluate some Erlang code against the running node

release-ctl eval @args
