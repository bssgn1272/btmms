## Restart the VM without exiting the process

release-remote-ctl restart
