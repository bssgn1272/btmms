this is the access control that is used to control user access to various parts of the system
the function of this project is to generate and print barcode codes that will grant the user access through the gates

index.php is the main class which receives the requests and processes the request to either create the jpeg image or return the json object which contains the barcode string
