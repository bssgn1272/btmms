<?php

class Configs{
	const INFO ='logs/info.log';
	const ERROR = 'logs/error.log';
        const FORMAT = 'jpeg';
        const IMAGEPATH = 'images/';

}

?>
