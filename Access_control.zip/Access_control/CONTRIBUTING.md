Each developer has a branch to work with.

Each developer is encouraged to create sub-branches to refine their version control.

Final merges should be made to development-master by NAPSA.

Communicate all pull requests, commits, etc.
